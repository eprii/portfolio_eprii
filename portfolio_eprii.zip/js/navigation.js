(() => {
  const key = "__efriNav";
  window[key]?.disconnect();

  const header = document.getElementById("site-header");
  const toggle = document.querySelector(".nav-toggle");
  const panel = document.getElementById("nav-panel");
  const progress = document.getElementById("scroll-progress");
  const backTop = document.getElementById("back-top");
  const links = [...document.querySelectorAll(".nav-list a, .nav-panel a")];
  const sections = [...document.querySelectorAll("main section[id]")];
  const ac = new AbortController();
  const { signal } = ac;
  const observers = [];

  const closePanel = () => {
    if (!toggle || !panel) return;
    toggle.setAttribute("aria-expanded", "false");
    toggle.setAttribute("aria-label", "Open menu");
    panel.classList.remove("is-open");
  };

  toggle?.addEventListener(
    "click",
    () => {
      const open = toggle.getAttribute("aria-expanded") === "true";
      toggle.setAttribute("aria-expanded", String(!open));
      toggle.setAttribute("aria-label", open ? "Open menu" : "Close menu");
      panel?.classList.toggle("is-open", !open);
    },
    { signal }
  );

  panel?.addEventListener(
    "click",
    (event) => {
      if (event.target instanceof HTMLAnchorElement) closePanel();
    },
    { signal }
  );

  document.addEventListener(
    "keydown",
    (event) => {
      if (event.key === "Escape") closePanel();
    },
    { signal }
  );

  const onScroll = () => {
    const doc = document.documentElement;
    const max = doc.scrollHeight - doc.clientHeight;
    const ratio = max > 0 ? doc.scrollTop / max : 0;
    if (progress) progress.style.width = `${Math.min(1, Math.max(0, ratio)) * 100}%`;
    header?.classList.toggle("is-compact", window.scrollY > 24);
    backTop?.classList.toggle("is-visible", window.scrollY > window.innerHeight * 0.7);
  };

  window.addEventListener("scroll", onScroll, { passive: true, signal });
  onScroll();

  if (location.hash.length > 1) {
    scrollToSection(decodeURIComponent(location.hash.slice(1)), false);
  }

  backTop?.addEventListener(
    "click",
    () => {
      window.scrollTo({
        top: 0,
        behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth",
      });
    },
    { signal }
  );

  const navClearance = () => {
    const pill = document.querySelector(".nav-pill");
    const top = header?.getBoundingClientRect().top ?? 16;
    const height = pill?.getBoundingClientRect().height ?? 44;
    return Math.round(top + height + 14);
  };

  const scrollToSection = (id, smooth = true) => {
    const motion = smooth && !matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (!id || id === "hero") {
      window.scrollTo({ top: 0, behavior: motion ? "smooth" : "auto" });
      return;
    }
    const section = document.getElementById(id);
    if (!section) return;
    const heading = section.querySelector(".section-header") || section;
    const top = heading.getBoundingClientRect().top + window.scrollY - navClearance();
    window.scrollTo({
      top: Math.max(0, top),
      behavior: motion ? "smooth" : "auto",
    });
  };

  document.addEventListener(
    "click",
    (event) => {
      const origin = event.target instanceof Element ? event.target : event.target?.parentElement;
      const link = origin instanceof Element ? origin.closest('a[href^="#"]') : null;
      if (!link) return;
      const href = link.getAttribute("href");
      if (!href || href === "#") return;
      const id = decodeURIComponent(href.slice(1));
      if (!document.getElementById(id)) return;
      event.preventDefault();
      closePanel();
      scrollToSection(id);
      history.pushState(null, "", href);
    },
    { signal }
  );

  const spy = new IntersectionObserver(
    (entries) => {
      const visible = entries
        .filter((e) => e.isIntersecting)
        .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
      if (!visible?.target?.id) return;
      links.forEach((link) => {
        const active = link.getAttribute("href") === `#${visible.target.id}`;
        link.classList.toggle("is-active", active);
        if (active) link.setAttribute("aria-current", "location");
        else link.removeAttribute("aria-current");
      });
    },
    { rootMargin: "-35% 0px -50% 0px", threshold: [0.1, 0.25, 0.5] }
  );

  sections.forEach((section) => spy.observe(section));
  observers.push(spy);

  window[key] = {
    disconnect() {
      ac.abort();
      observers.forEach((o) => o.disconnect());
    },
  };
})();
